num=float(input("enter no of sqrt_root"))
num_sqrt=num**.5
print(num_sqrt)

sum=0
prod=1
n=int(input("enter no"))
while(n>0):
    r=n%10
    sum=sum+r
    prod=prod*r
    n=n//10
if(sum==prod):
    print("spy no")
else:
    print("not spy")


n=int(input("enter no"))
rev=0
while(n>0):
    r=n%10
    rev=rev*10+r
    n=n//10
print(rev)


n=int(input("enter no"))
sum=0
while(n>0):
    r=n%10
    sum=sum+r
    n=n//10
print(sum)

p=int(input("enter pincipal amount"))
r=float(input("enter rate"))
t=int(input("enter time"))
i=(p*r*t)/100
print("interest is:{0:.2f}".format(i))

d=int(input("enter distance"))
t=int(input("enter time"))
s=d/t
print("speed is:{0:.2f}(kms/hr)" .format(s))

radius=int(input("enter radius of circle"))
area=3.14*radius**2
print("area of circle:{0:.2f}" .format(area))


